import About from "./components/about/About";
import Testimonial from "./components/testimonial/Testimonial.JSX";
import Tracks from "./components/track/Tracks";
import Tracks2 from "./components/track2/Tracks2";
import Hero from "./components/Hero";
import Header from "./components/Header";
import Features from "./components/features";
import Footer from "./components/Footer";


function App() {
  return (
    <div>
      <Header />
      <Hero />
      <Features />
      <Tracks />
      <About />
      <Testimonial />
      <Tracks2 />
      <Footer />
    </div>
  );
}

export default App;
