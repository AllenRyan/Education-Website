import React, { useState } from 'react';


const Header = () => {
  const [toggle, setToggle] = useState(false)
  return (
    <header className='header'>
       <nav className="navbar">
        <div className="logo">
            <img src="/images/logo.png" alt="Logo" />
        </div>
        <ul className="nav-menu">
          <li className='hideOnSmallScreen'><a className='active' href='#'>Home</a></li>
          <li className='hideOnSmallScreen'><a href='#'>About Us</a></li>
          <li className='hideOnSmallScreen'><a href='#'>Courses</a></li>
          <li className='hideOnSmallScreen'><a href='#'>Our Services</a></li>
          <li className='hideOnSmallScreen'><a href='#'>Contact us</a></li>
          <li><a className='signIn-btn' href='#'>Sign in</a></li>
          <li><img className='menuIcon menuImg' src='/images/menu-icon.png' alt='Menu-icon'></img></li>
        </ul>
       </nav>
    </header>
  )
}

export default Header;