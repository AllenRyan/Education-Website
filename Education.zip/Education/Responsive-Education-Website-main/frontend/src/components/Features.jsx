import React from 'react'

const Features = () => {
  return (
    <section className="features">
        <div className="container">
            <div className="image-container">
                <img src="/images/course.png" alt="course-icon" />
            </div>
            <div className="feature-content">
               <h2 className="feature-title">Learn The Latest Skills</h2>
                <p className="feature-text">Discover new skills effortlessly on our platform, with courses tailored to boost your knowledge and growth</p>
                
            </div>
        </div>
        <div className="container">
            <div className="image-container">
                <img src="/images/exam.png" alt="Career-icon" />
            </div>
             <div className="feature-content">
                <h2 className="feature-title">Get Ready For A Career</h2>
                 <p className="feature-text">Prepare for a successful career with our skill-focused courses designed to empower and elevate your future</p>
            </div>
        </div>
        <div className="container">
            <div className="image-container">
                <img src="/images/certificate.png" alt="Certificate-icon" />
            </div>
             <div className="feature-content">
                <h2 className="feature-title">Earn a Certificate</h2>
                  <p className="feature-text">Earn recognized certificates through our courses, showcasing your skills and achievements</p>
            </div>
        </div>
    </section>
  )
}

export default Features