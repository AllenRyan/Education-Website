import React,{useEffect} from 'react'

const Hero = () => {

  useEffect(() => {
  document.title = 'Education-Website Responsive'
  }, [])

  
  return (
      <section className="hero">
        <div className="hero-content">
          <h1 className="hero-heading">
            The <span className='orange-text'>Smart</span><br /> Choice For <span className='orange-text'>Future</span>
          </h1>
          <p className="hero-text">Eleam is a global training provider based across the Uk that specialises in accredited and bespoke training courses.</p>

          <div className="hero-input">
            <img className='SearchIcon' src="/images/search-icon.png" alt="search-icon" />
            <input type="text" className="hero-input" placeholder='Search for a location...' />

            <a className='continue-btn' href="#">Continue</a>
          </div>

        </div>
        <div className="image-wrapper">

          <img src="/images/hero.png" alt="HeroPic" />
        </div>
      </section>
  );
}

export default Hero;