import React from 'react'

const Footer = () => {
  return (
    <div className="footer-container">
        <div className="news-section">
            <h1 className="news-heading">Subscribe to our newsletter</h1>
            <p className="news-text">Subscribe to our newsletter for exclusive updates, career tips, and the latest course offerings!</p>
            <div className="input-container">
            <input type="email" placeholder='Email Address' />
            <a className='news-btn' href="#">Send</a>
            </div>
           
        </div>
    </div>
  )
}

export default Footer